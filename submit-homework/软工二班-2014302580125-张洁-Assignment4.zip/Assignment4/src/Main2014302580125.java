import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.sql.SQLException;
import javax.swing.*;

public class Main2014302580125 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new SearchEngine();
		/*JTextField t=new JTextField();
		t.setBounds(20, 20, 100, 10);
		//t.setEditable(true);
		//t.setBorder(BorderFactory.createLineBorder(Color.yellow, 2));
		p.add(t)*/;
	}

}

class SearchEngine extends JFrame  {
	static int state=0;
	static String input="";
	static ArrayList<String> information;
	
	public SearchEngine(){
		JFrame p=new JFrame();
		p.setTitle("SearchEngine");
		p.setBounds(400,200,500,400);
		//p.setLocationRelativeTo(null);
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p.setLayout(null);
		p.setVisible(true);
		p.setResizable(false);
		
		JTextField tf=new JTextField();
		tf.setSize(250,30);
		tf.setLocation(20,20);
		p.add(tf);
		
		JTextArea ta=new JTextArea();
		JScrollPane sp=new JScrollPane(ta);
		ta.setEditable(false);
		sp.setBounds(20, 80, 400, 250);
		sp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		//ta.setCaretPosition(0);
		p.add(sp);
		p.repaint();
		
		Button button=new Button("Search");
		button.setSize(100,30);
		button.setLocation(300,20);
		p.add(button);
		p.repaint();
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
                    input = tf.getText();
				DataReader dataReader=new DataReader();
				//System.out.print(dataReader.len[1]);
				try {
				information=dataReader.readMysql();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				information.sort(new StringComparator());

                if (state==0)
                {
                    ta.setText("No search results!"+"\n"+"Pay attention to the case!");
                    return;
                }
               
                String searchResult = "";   
                  String[] ss=new String[30];
                for (String s : information)
                	searchResult = searchResult+s + "\n";
                 ss= searchResult.split("\\*");
                 ta.setText(ss[1]);
                 ta.setCaretPosition(0);
               
                state=0;
			}
		});
		
		
	}
class StringComparator implements Comparator<String>{

	public int compare(String s1,String s2) {
		// TODO Auto-generated method stub
		int count1,count2;
		count1=count2=0;
		String s=SearchEngine.input;
		Pattern p=Pattern.compile(s);
		if(s1.contains(s)||s2.contains(s))
			SearchEngine.state=1;
		//Pattern p=Pattern.compile(s);
		 Matcher m1 = p.matcher(s1);
	        Matcher m2 = p.matcher(s2);
	
	        while (m1.find()) 
	        	count1++;
	        while (m2.find()) 
	        	count2++;

	        if (count1 < count2)
	            return 1;
	        else if(count1>count2)
	        return -1;
	        else
	        	return 0;
	}


	
}
}

