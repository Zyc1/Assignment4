import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DataReader {

	//public static int[] len=new int[26];
		public ArrayList<String> readMysql() throws ClassNotFoundException, SQLException{
			ArrayList<String>  mylist=new ArrayList<>();
			Connection conn = null;
	        //String sql;
			
	       // String url = "jdbc:mysql://localhost:3306/javademo?user=root&password=ZhangJie1441160&useUnicode=true&characterEncoding=UTF8";
	       String url= "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456 ";
	       
	        Class.forName("com.mysql.jdbc.Driver");
	      /*   ��̬����mysql����
	        System.out.println("�ɹ�����MySQL��������");
	               һ��Connection����һ�����ݿ�����*/
	        conn = DriverManager.getConnection(url);
	        Statement stmt = conn.createStatement();
	        ResultSet res = stmt.executeQuery("select * from javademo.2014302580125_professor_info");
	       while(res.next()){
	    	 /*for(int i=0;i<26;i++){
	    		 mylist.add(res.getString(1)+res.getString(2)+res.getString(3)+res.getString(4)+res.getString(5));
	        	 len[i]=res.getString(1).length()+res.getString(2).length()+res.getString(3).length()+res.getString(4).length()+res.getString(5).length();
	        	// System.out.print(len[i]);
	    		 //System.out.print("hello");
	    	 }*/
	    	  // ProfessorInfo pr=new ProfessorInfo(res.getString(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5));
	    	 mylist.add(res.getString(1)+res.getString(2)+res.getString(3)+res.getString(4)+res.getString(5));
	    	    //mylist.add(pr);
	    	  /* mylist.add(res.getString(1));
	    	  mylist.add(res.getString(2));
	    	   mylist.add(res.getString(3));
	    	   mylist.add(res.getString(4));
	    	   mylist.add(res.getString(5));*/
	       }
	        return mylist;
		}
}
