import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class KeywordsMatcher2014302580113 {

	private List<String> keywords;
	public ArrayList<SearchResult2014302580113> searchResultList = new ArrayList<SearchResult2014302580113>();
	private String[] stopWords = {"the","a","an","of","The",",","and","for","in"};
	private double tf;	
	
	//����Ҫ���ԵĴʴ���list
	private List<String> buildStopList()
	{
		List<String> stopList = Arrays.asList(stopWords);
		return stopList;
	}
	
	//��ȡ�ؼ���
	private List<String> fetchKeywords(String text)
	{
		if(text!=null){
			keywords = Arrays.asList(text.split(" "));
		}
		return keywords;
	}
	/**
	 * ����tfֵ	
	 * @param professorList
	 */
	public void calTF(ArrayList<ProfessorInfo2014302580113> professorList)
	{
		for(int i=0;i<professorList.size();i++)
		{
			ProfessorInfo2014302580113 professor = professorList.get(i);
			String str = professor.getName()+professor.getEducationBackground()+professor.getResearchInterests();
			List<String> list = Arrays.asList(str.split("\\s"));//��ÿ�����ݽ��зִʲ�����list��
			int total = list.size();
			List<String> stopList = buildStopList();
			keywords = fetchKeywords(new MainWindow2014302580113().getKeywords());
			//����ʣ����ʵȴ��ܴ�����ȥ��
			for(int j=0;j<list.size();j++){
				for(int k=0;k<stopList.size();k++)
				{
					if(list.get(j).equals(stopList.get(k)))
					{
						total--;
					}
				}
			}
			//ͳ�ƹؼ��ֳ��ֵĴ���
			int times = 0;
			for(int m=0;m<list.size();m++)
			{
				for(int n=0;n<keywords.size();n++)
				{
					if(list.get(m).equals(keywords.get(n)))
					{
						times++;
					}
				}
			}
			//�����ֹؼ��ֵ����ݴ���SearchResultList�У���������Ӧ��tfֵ
			if(times!=0)
			{
				tf = (double)times/total;
				SearchResult2014302580113 result = new SearchResult2014302580113(professor,tf);
				result.setPi(professor);
				result.setTf(tf);
				searchResultList.add(result);
			}
		}
	}
	
	//��SearchResultList����Ȩ���ɴ�С����
	public ArrayList<SearchResult2014302580113> sort()
	{
		ResultComparator2014302580113 comp = new ResultComparator2014302580113();
		Collections.sort(searchResultList,comp);
		return searchResultList;
	}
	
}
