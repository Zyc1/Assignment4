import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class DataReader2014302580113 {
	
	private String connectionString;
	private String user;
	private String password;
	Connection mycon = null;
	
	//�������ݿ�
	public void getConnection(String connectionString,String user,String password)
	{
		this.connectionString = connectionString;
		this.user = user;
		this.password = password;
		
		try {
        	Class.forName("com.mysql.jdbc.Driver");
            mycon = DriverManager.getConnection(connectionString,user,password);
            } catch (Exception e) {
    				e.printStackTrace();
    		}
	}
	
	//��ȡ���ݿ���Ϣ
	public ArrayList<ProfessorInfo2014302580113> excute(String sql) throws SQLException
	{
		Statement st=null;
	    ResultSet rs=null;
	    ArrayList<ProfessorInfo2014302580113> professorList=new ArrayList<ProfessorInfo2014302580113>();
	    try{
		    st=mycon.createStatement();
	        rs=st.executeQuery(sql);
	
		    while(rs.next())
	        {
		    	String name = rs.getString("name");
		    	Map<String,String> contactInfo = new HashMap<String,String>();
			    contactInfo.put(rs.getString("email"),rs.getString("phone") );
			    String educationBackground = rs.getString("educationBackground");
			    String researchInterests = rs.getString("researchInterests");
			    ProfessorInfo2014302580113 professor=new ProfessorInfo2014302580113(name,contactInfo,educationBackground,researchInterests);
			    professor.setName(name);
			    professor.setContactInfo(contactInfo);
			    professor.setEducationBackground(educationBackground);
			    professor.setResearchInterests(researchInterests);
			    professorList.add(professor);
	        }
	
			return professorList;
	    }finally {
			try {
				mycon.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
