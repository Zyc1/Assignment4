import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class MainWindow2014302580113 extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String keywords;
	JTextArea textArea = new JTextArea();

	public MainWindow2014302580113()
	{
		JTextField textField = new JTextField();
		textField.setFont(new Font("Serif",Font.PLAIN,20));
		textArea.setFont(new Font("Serif",Font.PLAIN,20));
		JButton btn = new JButton("Search");
		btn.setFont(new Font("Serif",Font.BOLD,20));
		
		JPanel p = new JPanel(new GridLayout (1, 2));
		p.add(textField);
		p.add(btn);
		p.setPreferredSize(new Dimension(400,50));
		p.setMaximumSize(new Dimension(400,50));
		p.setMinimumSize(new Dimension(400,50));
		
		setLayout (new BorderLayout());
		add(p,BorderLayout.NORTH);
		add(new JScrollPane(textArea),BorderLayout.CENTER);
		
		btn.addActionListener(new ActionListener() {
	           public void actionPerformed(ActionEvent e)
	           {
		           keywords = textField.getText();
		           textArea.setText("");
		           try {
					run();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	           }
	       });
	}
	
	private void run() throws SQLException
	{
		 ArrayList<ProfessorInfo2014302580113> professorList=new ArrayList<ProfessorInfo2014302580113>();
		 DataReader2014302580113 reader = new DataReader2014302580113();
		 reader.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");
		 professorList = reader.excute("select * from 2014302580113_professor_info");
		 KeywordsMatcher2014302580113 matcher = new KeywordsMatcher2014302580113();
		 matcher.calTF(professorList);
		 ArrayList<SearchResult2014302580113> searchResultList=matcher.sort();
		 
		 //����ȡ���������Ϣ��ʾ��textarea��
		 if(searchResultList.size()==0){
			 textArea.append("δ�ҵ������Ϣ");
		 }
		 else{
			 for(int i=0;i<searchResultList.size();i++)
			 {
				 ProfessorInfo2014302580113 professor = searchResultList.get(i).getPi();
				 textArea.append(professor.getName()+"\n"+professor.getEducationBackground()
						 +professor.getResearchInterests()+"\n");
			 }
		 }
	}
	
	public String getKeywords()
	{
		return keywords;
	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		MainWindow2014302580113 my_searcher=new MainWindow2014302580113();
	    my_searcher.setTitle("Professor Searcher");
	    my_searcher.setBounds(100, 100, 400, 500);
	    my_searcher.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    my_searcher.setVisible(true);
	    
	}

}
