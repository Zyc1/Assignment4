
public class SearchResult2014302580113 {
	
	private ProfessorInfo2014302580113 pi;
	private double tf;
	
	public SearchResult2014302580113(ProfessorInfo2014302580113 pi,double tf)
	{
		this.pi = pi;
		this.tf = tf;
	}

	public double getTf() {
		return tf;
	}

	public void setTf(double tf) {
		this.tf = tf;
	}

	public ProfessorInfo2014302580113 getPi() {
		return pi;
	}

	public void setPi(ProfessorInfo2014302580113 pi) {
		this.pi = pi;
	}
}
