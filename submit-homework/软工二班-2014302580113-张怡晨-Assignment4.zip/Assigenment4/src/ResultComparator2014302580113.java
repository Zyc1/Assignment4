import java.util.Comparator;


public class ResultComparator2014302580113 implements Comparator<SearchResult2014302580113>{
	
	@Override
	public int compare(SearchResult2014302580113 sr1,SearchResult2014302580113 sr2) {
		// TODO Auto-generated method stub
		if (sr1.getTf() < sr2.getTf()) 
        { 
            return 1; 
        } 
        else if (sr1.getTf() > sr2.getTf()) 
        { 
            return -1; 
        } 
        else 
        { 
            return 0; 
        }
	}
}
