import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.HashMap;
import com.mysql.jdbc.Statement;

public class DataSearch {
	
	
	private static  String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	//private static  String url="jdbc:mysql://127.0.0.1:3306/my_schema?"+"user=root&password=1461512xiaweiliaozebinzty628";
	private static Connection conn=null;
	// TODO Auto-generated method stub
	//���ӵ����ݿ�
	public static Connection getConnection(String url){
		
		try{
			  Class.forName("com.mysql.jdbc.Driver");
			 
		} catch (ClassNotFoundException e) {
			   // TODO Auto-generated catch block
			   e.printStackTrace();
			   System.out.print("\n���ݿ�����������");
		}
		 
		 try {
		       conn = (Connection) DriverManager.getConnection(url);
		       System.out.print("\n�ɹ����ӵ����ݿ�");
				  
			  } catch (SQLException e) {
			// TODO Auto-generated catch block
			   e.printStackTrace();
			   System.out.print("\nSQL����");
			  
			  }finally{
				  
			  }
		return conn;
		 }
	public static java.util.List<HashMap<String, String>>  read() throws SQLException{
		//ArrayList<Professorinfo129> p=new ArrayList<Professorinfo129>();
		getConnection(url);  //���ӵ����ݿ�
		//������ݿ��е����ݴ���data��
		java.util.List<HashMap<String,String>> data = new ArrayList<HashMap<String,String>>();
		try{
		Statement stmt = (Statement) conn.createStatement();
		 ResultSet rs = stmt.executeQuery("SELECT  * FROM 2014302580129_professor_info");
		 while (rs.next()){
             HashMap<String,String> map = new HashMap<String,String>();
             map.put("name", rs.getString(1));
             map.put("educationBackground", rs.getString(2));
             map.put("researchInterests", rs.getString(3));
             map.put("email", rs.getString(4));
             map.put("phone", rs.getString(5));
             data.add(map);
			
          }
		 } catch (SQLException e){
              e.printStackTrace();
          }finally{
              conn.close();
          }

		return data;
	}
	
}

