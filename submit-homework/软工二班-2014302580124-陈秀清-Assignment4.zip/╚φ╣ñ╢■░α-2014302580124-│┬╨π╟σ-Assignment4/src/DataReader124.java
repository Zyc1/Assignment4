import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DataReader124 {
	private String url = "jdbc:mysql://localhost:3306/my_schema";
    private String driver = "com.mysql.jdbc.Driver";
    Connection conn=null;
    Statement stmt = null;
    ResultSet rs=null;
    //�������ݿ�
    public Connection getConn(){
   	 try {
            Class.forName(driver);
            conn = (Connection) DriverManager.getConnection(url, "root", "cxqcxq1995");          
            System.out.println("���ݿ����ӳɹ���");} catch (ClassNotFoundException e) {
                System.out.println("���ݿ����������ڣ�");
                System.out.println(e.toString());             
            } catch (SQLException e) {
                System.out.println("SQL����");
                System.out.println(e.toString());
            } finally {
           	
                }
   return conn;	
   }//end method getconn 
    //��ȡ��������
    public ArrayList<ProfessorInfo124>readInfo() throws SQLException{
    	Connection connection=getConn();
    	Statement stmt = null;
        ResultSet rs=null;
         stmt = connection.createStatement();
         rs=stmt.executeQuery("select*from 2014302580124_professor_info");
         ArrayList<ProfessorInfo124> professorlist=new ArrayList<ProfessorInfo124>();
         while(rs.next()){
        	 String name=rs.getString(1).toLowerCase();
        	 String educationbackground=rs.getString(2).toLowerCase();
        	 String researchinterest=rs.getString(3).toLowerCase();
        	 String email=rs.getString(4).toLowerCase();
        	 String phone=rs.getString(5).toLowerCase();
        	 professorlist.add(new ProfessorInfo124(name,educationbackground,researchinterest,email,phone));
         }
         return professorlist;
    }//end method readInfo
}//end class DataReader124
