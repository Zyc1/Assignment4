
public class ProfessorInfo124 {
private String name;
private String educationBackground;
private String researInterests;
private String email;
private String phone;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEducationBackground() {
	return educationBackground;
}
public void setEducationBackground(String educationBackground) {
	this.educationBackground = educationBackground;
}
public String getResearInterests() {
	return researInterests;
}
public void setResearInterests(String researInterests) {
	this.researInterests = researInterests;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public ProfessorInfo124(String name,String edubg,String research,String email,String phone){
	this.name=name;
	this.educationBackground=edubg;
	this.researInterests=research;
	this.email=email;
	this.phone=phone;
}
}//end class ProfessorInfo124