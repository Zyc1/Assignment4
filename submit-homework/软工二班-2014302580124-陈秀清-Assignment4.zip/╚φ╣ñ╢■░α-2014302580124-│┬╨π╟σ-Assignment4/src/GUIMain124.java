import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GUIMain124 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		//DataReader124 dr=new DataReader124();
		/*
ArrayList<ProfessorInfo124>prolist ;
String search;
Scanner input=new Scanner(System.in);
System.out.println("please enter the information\n");
search=input.nextLine();
KeywordMatcher124 kw=new KeywordMatcher124();
kw.calTF(search.toLowerCase());
prolist=kw.getprolis();
if(prolist.size()==0) System.out.println("NOT FOUND!");
for(ProfessorInfo124 p:prolist){
	System.out.println("name:"+p.getName());
	System.out.println("EducationBackground:"+p.getEducationBackground());
	System.out.println("ResearchInterest:"+p.getResearInterests());
	System.out.println("Email:"+p.getEmail());
	System.out.println("Phone"+p.getPhone());
	System.out.println("����������������������������������������������������");
}*/
		JFrame myframe=new GUIMain124();
		myframe.setTitle("Professor Searcher");
		myframe.pack();
		myframe.setLocationRelativeTo(null);
		myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myframe.setVisible(true);
	}//end main method 
	GUIMain124(){
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel();
		JButton jbtsearch=new JButton("Search");
		JTextField jtainput=new JTextField(20);//(columns)
		JTextArea jtaresult=new JTextArea(15,30);//(rows ,columns)
		jtaresult.setLineWrap(true);//�����Զ����й���
		jtaresult.setWrapStyleWord(true);//������в����ֹ���
		jtaresult.setEditable(false);//����Ϊ���ɱ༭
		p1.add(jtainput);
		p2.add(jbtsearch);
		p3.add(jtaresult);
		p4.add(p1,BorderLayout.WEST);
		p4.add(p2, BorderLayout.EAST);
		add(p4,BorderLayout.NORTH);
		add(new JScrollPane(jtaresult),BorderLayout.CENTER);
		jbtsearch.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				
				String search=jtainput.getText();
				try {
					
					KeywordMatcher124 kw;
					kw = new KeywordMatcher124();
					kw.calTF(search.toLowerCase());
				    ArrayList<ProfessorInfo124>prolist ;
				    prolist=kw.getprolis();
				    if(prolist.size()==0) jtaresult.setText("Not Found");
				    else{
				    	for(ProfessorInfo124 p:prolist){
				    		String text=new String("name:"+p.getName()+"\n"
				    				+"EducationBackground:"+p.getEducationBackground()+"\n"
				    		+"ResearchInterest:"+p.getResearInterests()+"\n"
				    		+"Email:"+p.getEmail()+"\n"
				    		+"Phone"+p.getPhone()+"\n"
				    		+"����������������������������������������������������"+"\n");
				    	jtaresult.append(text);
				    	}
				    }
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
	}//end constructor
	
}//end class GUIMain124
