import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class KeywordMatcher124 {
private ArrayList<String> keywords=new ArrayList<String>();
private ArrayList <SearchResult124>searchresultlist=new ArrayList<SearchResult124>();
private ArrayList<String> stopWords=new ArrayList<String>();
private DataReader124 dr=new DataReader124();
KeywordMatcher124() throws SQLException{
	stopWords.add("of");
	stopWords.add("the");
	stopWords.add("a");
	stopWords.add("an");
	ArrayList<ProfessorInfo124> ptmp=new ArrayList<ProfessorInfo124>();
	ptmp=dr.readInfo();
	for(ProfessorInfo124 p:ptmp){
		searchresultlist.add(new SearchResult124(p));
	}
}//end constructor
private void fetchKeywords(String txt){
	String[] t=txt.split("\\s");
	keywords=new ArrayList<String>(Arrays.asList(t));
}//end method fetchKeywords

public void calTF(String input){
	fetchKeywords(input);
	
	for(int i=0;i<keywords.size();i++){
		if(stopWords.contains(keywords.get(i))) continue;//���ΪstopWords�Ĵ����˳��˴�ѭ��
		else {
			for(int n=0;n<searchresultlist.size();n++){
				double tf=0;
				String name=searchresultlist.get(n).getPi().getName();
				String edubg=searchresultlist.get(n).getPi().getEducationBackground();
				String researchinterest=searchresultlist.get(n).getPi().getResearInterests();
				String email=searchresultlist.get(n).getPi().getEmail();
				String phone=searchresultlist.get(n).getPi().getPhone();
				if(name.contains(keywords.get(i))) tf=tf+0.5;
				if(edubg.contains(keywords.get(i))) tf=tf+0.1;
				if(researchinterest.contains(keywords.get(i)))tf=tf+0.2;
				if(email.contains(keywords.get(i))) tf=tf+0.1;
				if(phone.contains(keywords.get(i))) tf=tf+0.1;
				//�ۼ�keywords��ĳ���ʵĴ�Ƶ
				    tf=tf+searchresultlist.get(n).getTf();//�ۼ�keywords�����дʵĴ�Ƶ
					searchresultlist.get(n).setTf(tf);
			}
		}
			
	}
}//end method calTF
public ArrayList<SearchResult124> sort(){
	SearchResultComparator srcom=new SearchResultComparator();
	Collections.sort(searchresultlist, srcom);
	return searchresultlist;
}//end method 
public ArrayList<ProfessorInfo124> getprolis(){
	ArrayList<ProfessorInfo124> prolist=new ArrayList<ProfessorInfo124>();
	for(SearchResult124 sr:searchresultlist){
		if(sr.getTf()>0) prolist.add(sr.getPi());
	}
	return prolist;
}//end method getprolist
 class SearchResultComparator implements Comparator<SearchResult124>{
	public int compare(SearchResult124 sr1,SearchResult124 sr2){
		if(sr1.getTf()>sr2.getTf()) return 1;
		else if(sr1.getTf()<sr2.getTf()) return -1;
		else return 0;
	}

	
}//end class SearchResultComparator
}//end class KeywordMatcher124
