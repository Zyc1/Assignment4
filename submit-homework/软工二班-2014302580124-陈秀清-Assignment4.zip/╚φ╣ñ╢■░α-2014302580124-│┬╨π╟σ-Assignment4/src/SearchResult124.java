
public class SearchResult124 {
private ProfessorInfo124 pi;
private double tf=0;
public SearchResult124(ProfessorInfo124 pi){
	this.pi=pi;
}//end constructor
public SearchResult124(ProfessorInfo124 pi,double tf){
	this.pi=pi;
	this.tf=tf;
}//end constructor
public ProfessorInfo124 getPi(){
	return pi;
}//end method getPi
public void setPi(ProfessorInfo124 pi){
	this.pi=pi;
}//end method setPi;
public double getTf() {
	return tf;
}//end method getTf
public void setTf(double tf) {
	this.tf = tf;
}//end method setTf

}//end class SearchResult124
